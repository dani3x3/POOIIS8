package HotelManagementApp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HotelDAO {
    public void agregarHotel(Hotel hotel) throws SQLException {
        String sql = "INSERT INTO hoteles (nombre, telefono, tarifa_por_noche) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, hotel.getNombre());
            stmt.setString(2, hotel.getTelefono());
            stmt.setDouble(3, hotel.getTarifaPorNoche());
            stmt.executeUpdate();
        }
    }

    public void eliminarHotel(int id) throws SQLException {
        String sql = "DELETE FROM hoteles WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    public List<Hotel> listarHoteles() throws SQLException {
        List<Hotel> hoteles = new ArrayList<>();
        String sql = "SELECT * FROM hoteles";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Hotel hotel = new Hotel(
                    rs.getString("nombre"),
                    rs.getString("telefono"),
                    rs.getDouble("tarifa_por_noche")
                );
                hotel.setId(rs.getInt("id"));
                hoteles.add(hotel);
            }
        }
        return hoteles;
    }
}
