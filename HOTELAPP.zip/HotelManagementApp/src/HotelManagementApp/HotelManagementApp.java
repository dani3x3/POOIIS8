package HotelManagementApp;

public class HotelManagementApp {
    public static void main(String[] args) {
        HotelManagementGUI gui = new HotelManagementGUI();
        gui.setVisible(true);
    }
}
