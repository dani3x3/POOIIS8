package HotelManagementApp;

public class Hotel {
    private int id;
    private String nombre;
    private String telefono;
    private double tarifaPorNoche;

    public Hotel(String nombre, String telefono, double tarifaPorNoche) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.tarifaPorNoche = tarifaPorNoche;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public double getTarifaPorNoche() {
        return tarifaPorNoche;
    }

    public void setTarifaPorNoche(double tarifaPorNoche) {
        this.tarifaPorNoche = tarifaPorNoche;
    }
}
