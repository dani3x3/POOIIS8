package HotelManagementApp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class HotelManagementGUI extends JFrame {
    private HotelDAO hotelDAO;
    private JTextField nombreField;
    private JTextField telefonoField;
    private JTextField tarifaField;
    private JTextArea listadoArea;

    public HotelManagementGUI() {
        hotelDAO = new HotelDAO();
        setTitle("Gestión de Hoteles");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel entradaPanel = new JPanel(new GridLayout(4, 2));
        entradaPanel.add(new JLabel("Nombre:"));
        nombreField = new JTextField();
        entradaPanel.add(nombreField);
        entradaPanel.add(new JLabel("Teléfono:"));
        telefonoField = new JTextField();
        entradaPanel.add(telefonoField);
        entradaPanel.add(new JLabel("Tarifa por noche:"));
        tarifaField = new JTextField();
        entradaPanel.add(tarifaField);

        JButton agregarButton = new JButton("Agregar Hotel");
        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarHotel();
            }
        });
        entradaPanel.add(agregarButton);

        JButton eliminarButton = new JButton("Eliminar Hotel");
        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarHotel();
            }
        });
        entradaPanel.add(eliminarButton);

        add(entradaPanel, BorderLayout.NORTH);

        listadoArea = new JTextArea();
        add(new JScrollPane(listadoArea), BorderLayout.CENTER);

        cargarHoteles();
    }

    private void agregarHotel() {
        String nombre = nombreField.getText();
        String telefono = telefonoField.getText();
        double tarifa;
        try {
            tarifa = Double.parseDouble(tarifaField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Tarifa inválida", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Hotel hotel = new Hotel(nombre, telefono, tarifa);
        try {
            hotelDAO.agregarHotel(hotel);
            cargarHoteles();
            JOptionPane.showMessageDialog(this, "Hotel agregado exitosamente");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al agregar hotel", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarHotel() {
        String idStr = JOptionPane.showInputDialog(this, "Ingrese el ID del hotel a eliminar:");
        int id;
        try {
            id = Integer.parseInt(idStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID inválido", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            hotelDAO.eliminarHotel(id);
            cargarHoteles();
            JOptionPane.showMessageDialog(this, "Hotel eliminado exitosamente");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al eliminar hotel", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarHoteles() {
        try {
            java.util.List<Hotel> hoteles = hotelDAO.listarHoteles();
            listadoArea.setText("");
            for (Hotel hotel : hoteles) {
                listadoArea.append(hotel.getId() + ": " + hotel.getNombre() + " - " + hotel.getTelefono() + " - " + hotel.getTarifaPorNoche() + "\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar hoteles", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
